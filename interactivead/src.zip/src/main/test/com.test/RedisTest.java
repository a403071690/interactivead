package com.test;

import com.alibaba.fastjson.JSONObject;
import com.zc.entity.AdvertiserCampaign;
import com.zc.entity.CampaignCreativeReport;
import com.zc.service.CampaignCreativeReportService;
import com.zc.service.impl.CampaignCreativeReportServiceImpl;
import com.zc.util.RedisPool;
import org.solar.util.DateUtil;

import java.util.Date;
import java.util.List;

public class RedisTest {
    public static void main(String[] args){
        //RedisPool.getJedis().set("name222","adfad");
    //   RedisPool.getJedis().hset("cp","we123","{\"name\":\"zhajja\"}");
     //   System.out.println(RedisPool.getJedis().hget("cp","123123123"));

        //List<AdvertiserCampaign> cplist = JSONObject.parseArray(RedisPool.getJedis().hvals("cp").toString(),AdvertiserCampaign.class);
      //  System.out.println(cplist.get(0).getId());

        //CampaignCreativeReportService service = new CampaignCreativeReportServiceImpl();
       // List<CampaignCreativeReport> campaignCreativeReportList = service.selectByWhere("","");
//
        //年月日十秒显示日期时间
        System.out.println("当前时间："+ DateUtil.format(new Date()));
    }
}
