package com.zc.dao;

import com.zc.dao.BaseDao;
import com.zc.entity.UserPrizeLog;

/**
 * @Description:
 * @author solar
 * @date 2018年03月26日 14:01
 */


public interface UserPrizeLogDao extends BaseDao<UserPrizeLog>{

}