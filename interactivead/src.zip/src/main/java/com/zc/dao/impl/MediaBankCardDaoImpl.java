package com.zc.dao.impl;

import com.zc.entity.MediaBankCard;
import com.zc.dao.MediaBankCardDao;
import org.springframework.stereotype.Repository;
import java.util.List;
/**
 * @Description:
 * @author solar
 * @date 2018年03月20日 22:41
 */
@Repository("MediaBankCardDao")
public class MediaBankCardDaoImpl extends BaseDaoImpl<MediaBankCard> implements MediaBankCardDao {

//    private final String demoSqlId = entityName + ".demoId";

//    public List demoMethod(Object obj) {
//        return sessionTemplate.selectList(demoSqlId, obj);
//    }

}