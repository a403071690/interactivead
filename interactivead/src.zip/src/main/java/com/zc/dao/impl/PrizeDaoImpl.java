package com.zc.dao.impl;

import com.zc.md.entity.Prize;
import com.zc.dao.PrizeDao;
import org.springframework.stereotype.Repository;

/**
 * @Description:
 * @author solar
 * @date 2018年03月20日 22:41
 */
@Repository("PrizeDao")
public class PrizeDaoImpl extends BaseDaoImpl<Prize> implements PrizeDao {

//    private final String demoSqlId = entityName + ".demoId";

//    public List demoMethod(Object obj) {
//        return sessionTemplate.selectList(demoSqlId, obj);
//    }

}