package com.zc.dao.impl;

import com.zc.entity.AdvertiserInfo;
import com.zc.dao.AdvertiserInfoDao;
import org.springframework.stereotype.Repository;
import java.util.List;
/**
 * @Description:
 * @author solar
 * @date 2018年03月20日 22:41
 */
@Repository("AdvertiserInfoDao")
public class AdvertiserInfoDaoImpl extends BaseDaoImpl<AdvertiserInfo> implements AdvertiserInfoDao {

//    private final String demoSqlId = entityName + ".demoId";

//    public List demoMethod(Object obj) {
//        return sessionTemplate.selectList(demoSqlId, obj);
//    }

}