package com.zc.dao;

import com.zc.md.entity.Prize;

/**
 * @Description:
 * @author solar
 * @date 2018年03月20日 22:41
 */


public interface PrizeDao extends BaseDao<Prize>{

}