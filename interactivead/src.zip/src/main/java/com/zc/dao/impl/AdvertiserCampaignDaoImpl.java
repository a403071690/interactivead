package com.zc.dao.impl;

import com.zc.entity.AdvertiserCampaign;
import com.zc.dao.AdvertiserCampaignDao;
import org.springframework.stereotype.Repository;
import java.util.List;
/**
 * @Description:
 * @author solar
 * @date 2018年03月20日 22:41
 */
@Repository("AdvertiserCampaignDao")
public class AdvertiserCampaignDaoImpl extends BaseDaoImpl<AdvertiserCampaign> implements AdvertiserCampaignDao {

//    private final String demoSqlId = entityName + ".demoId";

//    public List demoMethod(Object obj) {
//        return sessionTemplate.selectList(demoSqlId, obj);
//    }

}