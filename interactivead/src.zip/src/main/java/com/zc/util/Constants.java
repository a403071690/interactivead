package com.zc.util;

/**
 * Created by xianchuanwu on 2017/9/24.
 */
public class Constants {
    /**
     * dr字段 Y=该数据已删除。N=该数据未删除
     */
    public static final String Y="y";
    public static final String N="n";
}
