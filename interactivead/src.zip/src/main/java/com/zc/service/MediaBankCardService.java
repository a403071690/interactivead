package com.zc.service;

import com.zc.entity.MediaBankCard;
/**
 * @Description:
 * @author solar
 * @date 2018年03月20日 22:41
 */
public interface MediaBankCardService extends BaseService<MediaBankCard> {


}