package com.zc.service;

import com.zc.entity.UserPrizeLog;
import com.zc.service.BaseService;

/**
 * @Description:
 * @author solar
 * @date 2018年03月26日 14:01
 */
public interface UserPrizeLogService extends BaseService<UserPrizeLog> {


}