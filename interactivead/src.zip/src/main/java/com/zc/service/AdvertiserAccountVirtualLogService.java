package com.zc.service;

import com.zc.entity.AdvertiserAccountVirtualLog;
/**
 * @Description:
 * @author solar
 * @date 2018年03月20日 22:41
 */
public interface AdvertiserAccountVirtualLogService extends BaseService<AdvertiserAccountVirtualLog> {


}