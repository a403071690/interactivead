package com.zc.service;

import com.zc.entity.AdvertiserCampaign;
/**
 * @Description:
 * @author solar
 * @date 2018年03月20日 22:41
 */
public interface AdvertiserCampaignService extends BaseService<AdvertiserCampaign> {


}